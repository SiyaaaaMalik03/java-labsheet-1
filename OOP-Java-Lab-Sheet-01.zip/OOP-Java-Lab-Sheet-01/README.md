# Object Oriented Programming Using Java - Lab Sheet-01

MCA III Semester | COER University

Solutions of all 20 questions of Lab Sheet-01. Every question is in its own file; the file name
and the public class name are the same (for example `Q03_EvenOdd.java` contains `public class Q03_EvenOdd`).

## Programs

| File | Question |
|---|---|
| `Q01_DisplayDetails.java` | Display name, age and college name using variables of appropriate data types |
| `Q02_ArithmeticOperations.java` | Input two integers and print +, -, *, / and % results |
| `Q03_EvenOdd.java` | Even or odd using modulus operator and if-else |
| `Q04_RelationalOperators.java` | Relational operators by comparing two numbers |
| `Q05_TypeConversion.java` | Floating-point number to integer (explicit casting) |
| `Q06_AsciiValue.java` | ASCII value of a character |
| `Q07_DivisibleBy3And5.java` | Divisible by both 3 and 5 using logical operators |
| `Q08_VowelConsonant.java` | Vowel or consonant using if-else |
| `Q09_MarksPassFail.java` | Total, percentage and pass/fail of three subjects (>= 40% in all) |
| `Q10_GreatestOfTwo.java` | Greatest of two numbers |
| `Q11_LargestOfThree.java` | Largest of three numbers using nested if-else |
| `Q12_LeapYear.java` | Leap year check |
| `Q13_PositiveNegativeZero.java` | Positive, negative or zero |
| `Q14_CharacterClassification.java` | Digit, uppercase, lowercase or special character |
| `Q15_ArmstrongNumber.java` | Armstrong number (3-digit) |
| `Q16_IncomeTax.java` | Tax calculation using income slabs |
| `Q17_Palindrome.java` | Palindrome integer using arithmetic operations and type casting |
| `Q18_PrimeNumber.java` | Prime number check |
| `Q19_OperatorCalculator.java` | Valid operator check and calculation on two numbers |
| `Q20_MarriageEligibility.java` | Marriage eligibility using age, gender and nested if-else |

## How to run

**In VS Code:** install the *Extension Pack for Java*, open this folder, open any `Q..java` file and click
the **Run** button above `main` (or press `Ctrl+F5`). Input is typed in the terminal.

**From the terminal:**

    javac Q03_EvenOdd.java
    java Q03_EvenOdd

To compile all the programs at once: `javac *.java`

## Upload to GitHub

    git init
    git add .
    git commit -m "Add OOP Java Lab Sheet-01 solutions"
    git branch -M main
    git remote add origin https://github.com/<your-username>/<repository-name>.git
    git push -u origin main

(or use the **Source Control** panel in VS Code: *Initialize Repository -> Commit -> Publish Branch*).
