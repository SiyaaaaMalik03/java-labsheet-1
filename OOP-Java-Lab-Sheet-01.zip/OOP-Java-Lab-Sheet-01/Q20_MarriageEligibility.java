import java.util.Scanner;

/**
 * Lab Sheet-01 | Q20: Accept age and gender and determine eligibility for marriage
 * (male >= 21, female >= 18) using nested if-else conditions.
 */
public class Q20_MarriageEligibility {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter age: ");
            int age = sc.nextInt();
            System.out.print("Enter gender (M for male / F for female): ");
            char gender = Character.toUpperCase(sc.next().charAt(0));

            if (age < 0) {
                System.out.println("Invalid age.");
            } else if (gender == 'M') {
                if (age >= 21) {                       // nested if-else
                    System.out.println("Male, age " + age + ": ELIGIBLE for marriage.");
                } else {
                    System.out.println("Male, age " + age + ": NOT eligible (minimum age is 21).");
                }
            } else if (gender == 'F') {
                if (age >= 18) {
                    System.out.println("Female, age " + age + ": ELIGIBLE for marriage.");
                } else {
                    System.out.println("Female, age " + age + ": NOT eligible (minimum age is 18).");
                }
            } else {
                System.out.println("Invalid gender! Enter M or F.");
            }
        }
    }
}
